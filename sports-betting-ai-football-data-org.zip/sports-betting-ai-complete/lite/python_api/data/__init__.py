"""
Módulo de coleta de dados da API football-data.org
"""
from .collector import FootballDataCollector

__all__ = ['FootballDataCollector']
