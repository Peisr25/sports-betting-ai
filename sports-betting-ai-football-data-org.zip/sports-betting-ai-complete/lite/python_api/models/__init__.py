"""
Módulos de modelos de predição
"""
from .poisson import PoissonModel

__all__ = ['PoissonModel']
